#deltedelete-web
#####Web-app UI for DeleteDelete
---



# Install

####config

`ln -s /var/www/configs/deletedelete.dev.ini config.ini`

`cp env.ini.example env.ini` which contains `config_file = "/var/www/configs/deletedelete.dev.ini"`




